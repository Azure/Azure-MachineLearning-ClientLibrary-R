test_that("publishWebService() returns a working web service", {

})

test_that("Discovery functions allow discovery of endpoints to consume web service", {

})

test_that("Consumption functions are working and returning correct values", {

})
