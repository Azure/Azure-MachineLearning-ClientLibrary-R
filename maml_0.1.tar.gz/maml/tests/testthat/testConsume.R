test_that("Consumption for non-R published web service", {

})
