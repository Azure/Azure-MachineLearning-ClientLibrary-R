library(testthat)
library(maml)

test_check("maml")
